import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import { Element } from '@angular/compiler';
@Component({
    selector: 'home',
    templateUrl: './home.component.html'
})
export class HomeComponent{
    
}

