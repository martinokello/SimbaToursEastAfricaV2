import { Component, Inject } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'failure',
    templateUrl: './failure.component.html'
})
export class FailureComponent {
}

