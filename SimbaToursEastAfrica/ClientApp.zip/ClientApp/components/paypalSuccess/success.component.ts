import { Component, Inject } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'success',
    templateUrl: './success.component.html'
})
export class SuccessComponent {
}

