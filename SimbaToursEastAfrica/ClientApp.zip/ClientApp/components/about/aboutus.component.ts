import { Component, Inject } from '@angular/core';
import { Http } from '@angular/http';

@Component({
    selector: 'aboutus',
    templateUrl: './aboutus.component.html'
})
export class AboutUsComponent {
}

